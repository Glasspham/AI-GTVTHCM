from z3 import *

n = 4
Q = [Int(f'Q_{i}') for i in range(n)]
s = Solver()

s.add([And(0 <= Q[i], Q[i] < n) for i in range(n)])
s.add(Distinct(Q))
s.add([Q[i] != Q[j] + (i - j) for i in range(n) for j in range(i)])
s.add([Q[i] != Q[j] - (i - j) for i in range(n) for j in range(i)])

if s.check() == sat:
    m = s.model()
    solution = [m.evaluate(Q[i]).as_long() for i in range(n)]
    for i in range(n):
        row = ['Q' if solution[i] == j else '.' for j in range(n)]
        print(' '.join(row))
else:
    print("No solution")
