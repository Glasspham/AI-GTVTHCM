from z3 import *

def solve_n_queens(n=4):
    solver = Solver()
    
    x = [Int(f'x_{i}') for i in range(n)]
    
    solver.add([And(x[i] >= 0, x[i] < n) for i in range(n)])
    
    solver.add(Distinct(x))
    
    solver.add([x[i] - x[j] != i - j for i in range(n) for j in range(i)])
    solver.add([x[i] - x[j] != j - i for i in range(n) for j in range(i)])
    
    if solver.check() == sat:
        model = solver.model()
        solution = [model[x[i]].as_long() for i in range(n)]
        print_solution(solution, n)
    else:
        print("No solution found")

def print_solution(solution, n):
    board = [['.' for _ in range(n)] for _ in range(n)]
    for i in range(n):
        board[i][solution[i]] = 'Q'
    for row in board:
        print(" ".join(row))
    print()

solve_n_queens()