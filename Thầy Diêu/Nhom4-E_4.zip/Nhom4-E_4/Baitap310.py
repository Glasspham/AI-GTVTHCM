# Đề bài: Dùng thư viện sympy giải bài tập Prove using resolution that  
# P ⇒ (Q ∧ R) |= (¬Q ∨ ¬R) ⇒ ¬P

from sympy import symbols
from sympy.logic.boolalg import Implies, Not, And, Or
from sympy.logic.inference import satisfiable


# Khai báo biến
P, Q, R = symbols('P Q R')

# Biểu thức giả thuyết (premise) và kết luận (conclusion)
premise = Implies(P, And(Q, R))
conclusion = Implies(Or(Not(Q), Not(R)), Not(P))

# Kiểm tra suy diễn hợp lệ bằng phương pháp resolution:
# Theo logic: premise |= conclusion ⇔ premise ∧ ¬conclusion là UNSAT (mâu thuẫn)

def prove_entailment(premise, conclusion):
    combined = And(premise, Not(conclusion))
    return not satisfiable(combined)

# In kết quả kiểm tra
if prove_entailment(premise, conclusion):
    print("Biểu thức đúng: P ⇒ (Q ∧ R) |= (¬Q ∨ ¬R) ⇒ ¬P là một suy diễn hợp lệ.")
else:
    print("Biểu thức sai: P ⇒ (Q ∧ R) không suy diễn được (¬Q ∨ ¬R) ⇒ ¬P.")
