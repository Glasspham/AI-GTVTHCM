# Đề bài: Dùng thư viện sympy giải bài tập Convert into CNF
# a) P ⇔ Q
# b) (P ⇒ Q) ⇒ R
# c) (P ∨ Q) ∧ (P ∧ R)
# d) (A ∧ ¬¬B) ∨ (¬C ∧ D)
# e) (P ∨ (Q ∧ ¬A)) ∧ (¬P ∨ A ∨ ¬B)
# f) ¬(P ⇒ Q) ∨ ((R ∨ S) ⇒ (Q ∨ T)) ∨ (¬P ⇒ ¬V)
# g) P ⇒ (Q ∧ R)
# h) (P ∨ Q) ⇒ R
# i) ¬(¬P ∨ Q) ∨ (R ⇒ ¬S)
# j) ¬((P ⇒ (Q ⇒ R))) ⇒ ((P ⇒ Q) ⇒ (P ⇒ R))
# k) P ∨ (¬Q ∧ (R ⇒ ¬P))
# l) ¬((((A ⇒ B)) ⇒ A) ⇒ A)
# m) ¬(A ∨ (A ⇒ B))
# n) ¬P ∧ Q ∨ ¬(¬R ∨ ¬Q)

from sympy import symbols
from sympy.logic.boolalg import Implies, Equivalent, Not, Or, And, to_cnf

# Khai báo biến
P, Q, R, S, T, V, A, B, C, D = symbols('P Q R S T V A B C D')

# Các biểu thức logic
a = Equivalent(P, Q)
b = Implies(Implies(P, Q), R)
c = And(Or(P, Q), And(P, R))
d = Or(And(A, Not(Not(B))), And(Not(C), D))
e = And(Or(P, And(Q, Not(A))), Or(Not(P), A, Not(B)))
f = Or(Not(Implies(P, Q)), Implies(Or(R, S), Or(Q, T)), Implies(Not(P), Not(V)))
g = Implies(P, And(Q, R))
h = Implies(Or(P, Q), R)
i = Or(Not(Or(Not(P), Q)), Implies(R, Not(S)))
j = Implies(Implies(P, Implies(Q, R)), False) | Implies(Implies(P, Q), Implies(P, R))
k = Or(P, And(Not(Q), Implies(R, Not(P))))
l = Not(Implies(Implies(Implies(A, B), A), A))
m = Not(Or(A, Implies(A, B)))
n = Or(And(Not(P), Q), Not(Or(Not(R), Not(Q))))

# In ra kết quả CNF
print("a)", to_cnf(a, True))
print("b)", to_cnf(b, True))
print("c)", to_cnf(c, True))
print("d)", to_cnf(d, True))
print("e)", to_cnf(e, True))
print("f)", to_cnf(f, True))
print("g)", to_cnf(g, True))
print("h)", to_cnf(h, True))
print("i)", to_cnf(i, True))
print("j)", to_cnf(j, True))
print("k)", to_cnf(k, True))
print("l)", to_cnf(l, True))
print("m)", to_cnf(m, True))
print("n)", to_cnf(n, True))
