# Đề bài: Dùng thư viện sympy giải bài tập Prove with resolution that the following formulas are tautologies
# a) P ⇒ (Q ⇒ P)
# b) (P ∧ (P ⇒ Q)) ⇒ Q
# c) ((P ⇒ Q) ∧ ¬Q) ⇒ ¬P
# d) ((P ⇒ Q) ∧ ¬Q) ⇒ ¬Q

from sympy import symbols
from sympy.logic.boolalg import Implies, Not, And, Or
from sympy.logic.inference import satisfiable


# Khai báo biến
P, Q = symbols('P Q')

# Các biểu thức logic
a = Implies(P, Implies(Q, P))
b = Implies(And(P, Implies(P, Q)), Q)
c = Implies(And(Implies(P, Q), Not(Q)), Not(P))
d = Implies(And(Implies(P, Q), Not(Q)), Not(Q))

# Hàm kiểm tra tautology bằng resolution (nếu phủ định biểu thức là không thỏa mãn -> tautology)
def prove_tautology(expr):
    negated = Not(expr)
    return not satisfiable(negated)

# In kết quả kiểm tra
print("a)", "Tautology" if prove_tautology(a) else "Not a tautology")
print("b)", "Tautology" if prove_tautology(b) else "Not a tautology")
print("c)", "Tautology" if prove_tautology(c) else "Not a tautology")
print("d)", "Tautology" if prove_tautology(d) else "Not a tautology")
